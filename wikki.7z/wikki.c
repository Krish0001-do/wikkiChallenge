#include <stdint.h>
#include <stdio.h>
#include <math.h>
#define M 37
#define	q (2+M/M)
#define	v (q/q)
#define	ef ((v+q)/2)
#define	f (q-v-ef)
#define k (8-ef)
struct b{int64_t y[13];}S;int m=1811939329,N=1,t[1<<26]={2},a,*p,i,e=73421233,s,c,U=1;
g(d,h){for(i=s;i<1<<25;i*=2)d=d*1LL*d%m;for(p=t;p<t+N;p+=s)for(i=s,c=1;i;i--)a=p[s]*(h?c:1LL)%m,p[s]=(m*1U+*p-a)*(h?1LL:c)%m,*p=(a*1U+*p)%m,p++,c=c*1LL*d%m;}
l(){while(e/=2){N*=2;U=U*1LL*(m+1)/2%m;for(s=N;s/=2;)g(136,0);for(p=t;p<t+N;p++)*p=*p*1LL**p%m*U%m;for(s=1;s<N;s*=2)g(839354248,1);for(a=0,p=t;p<t+N;)a+=*p<<(e&1),*p++=a%10,a/=10;}}
z(n){int y=3,j,c;for(j=2;j<=n;){l();for(c=2;c<=y-1;c++){l();if(y%c==0)break;}if(c==y){l();j++;}y++;}l();return y-1;}
main(a, pq) char* pq;{int b=sizeof(S),y=b,j=M;l();
int x[M]= {102,108,97,103,123,104,105,95,97,108,108,95,119,69,108,99,111,109,69,95,116,104,105,115,95,116,97,115,107,125,
 0,0,0,0,0,0,0
};
while(j--){putchar(x[M-v-j]);}printf(" you got it\n");return 0;}
